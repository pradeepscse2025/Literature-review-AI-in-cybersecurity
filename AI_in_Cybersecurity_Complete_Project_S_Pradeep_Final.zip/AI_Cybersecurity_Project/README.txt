AI IN CYBERSECURITY – LITERATURE REVIEW PROJECT PACKAGE
Student: S Pradeep
Register Number: 410725104123

Included:
1. AI_in_Cybersecurity_Literature_Review.docx – editable academic report.
2. AI_in_Cybersecurity_Literature_Review.pdf – PDF version.
3. AI_in_Cybersecurity_Presentation.pptx – editable presentation.
4. References.txt – bibliography and source links.
5. README.txt – this file.

Before submission:
- Replace S Pradeep, 410725104123 and [GUIDE NAME].
- Confirm the department's required report format, page count and citation style.
- Verify all reference details and read the papers you cite.
- Add any required college logo, signatures, declaration wording and supervisor details.
- Edit the report in your own words and be prepared to explain the review methodology and findings.
- This is a literature review; it does not claim to contain original experimental results.
